package com.universal.autopilot.platform.notifications

import android.app.Notification
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput
import com.universal.autopilot.core.model.ActionResult
import com.universal.autopilot.core.model.ExecutionMethod
import timber.log.Timber

class AutopilotNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        instance = this
        Timber.i("BOB notification tap online")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val canReply = replyAction(sbn) != null
        NotificationBridge.onPosted(sbn.key, sbn.packageName, title, text, canReply)
        cache[sbn.key] = sbn
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        cache.remove(sbn.key)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun reply(packageName: String, text: String, keyContains: String?): ActionResult {
        val sbn = cache.values.lastOrNull { entry ->
            entry.packageName == packageName &&
                (keyContains.isNullOrBlank() || entry.notification.extras.toString().contains(keyContains, true) ||
                    entry.key.contains(keyContains, true))
        } ?: return ActionResult(false, ExecutionMethod.NOTIFICATION, "No live notification for $packageName")
        val action = replyAction(sbn)
            ?: return ActionResult(false, ExecutionMethod.NOTIFICATION, "No RemoteInput on notification")
        val inputs = action.remoteInputs ?: emptyArray()
        val sendIntent = Intent()
        val fill = Bundle()
        inputs.forEach { fill.putCharSequence(it.resultKey, text) }
        RemoteInput.addResultsToIntent(inputs, sendIntent, fill)
        return runCatching {
            action.actionIntent.send(this, 0, sendIntent)
            ActionResult(true, ExecutionMethod.NOTIFICATION, "Replied via RemoteInput")
        }.getOrElse {
            ActionResult(false, ExecutionMethod.NOTIFICATION, it.message ?: "send failed")
        }
    }

    private fun replyAction(sbn: StatusBarNotification): Notification.Action? {
        val actions = sbn.notification.actions ?: return null
        return actions.firstOrNull { action ->
            action.remoteInputs?.isNotEmpty() == true ||
                NotificationCompat.getAction(sbn.notification, actions.indexOf(action))
                    ?.remoteInputs
                    ?.isNotEmpty() == true
        }
    }

    companion object {
        @Volatile
        var instance: AutopilotNotificationListener? = null
            private set
        private val cache = LinkedHashMap<String, StatusBarNotification>()
    }
}
