package com.universal.autopilot.platform.actions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.universal.autopilot.core.model.ActionResult
import com.universal.autopilot.core.model.ActionStep
import com.universal.autopilot.core.model.ExecutionMethod
import com.universal.autopilot.core.model.UiGesture
import com.universal.autopilot.engine.DeviceActionGateway
import com.universal.autopilot.platform.accessibility.AccessibilityCommandBus
import com.universal.autopilot.platform.notifications.AutopilotNotificationListener
import com.universal.autopilot.platform.overlay.HudController
import com.universal.autopilot.platform.overlay.OverlayManager
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FallbackDeviceGateway @Inject constructor(
    @ApplicationContext private val context: Context,
    private val hud: HudController,
    private val overlay: OverlayManager,
    private val accessibility: AccessibilityCommandBus,
) : DeviceActionGateway {

    override suspend fun execute(step: ActionStep): ActionResult {
        overlay.ensureShown()
        hud.show("BOB EXEC", step::class.simpleName ?: "action", takeover = true)
        val intentAttempt = when (step) {
            is ActionStep.Call -> call(step.number)
            is ActionStep.Sms -> sms(step.number, step.message)
            is ActionStep.DeepLink -> deepLink(step.uri, step.packageName)
            is ActionStep.OpenApp -> openApp(step.packageName)
            is ActionStep.NotificationReply -> ActionResult(false, ExecutionMethod.INTENT, "use notification path")
            is ActionStep.UiMacro -> ActionResult(false, ExecutionMethod.INTENT, "use accessibility path")
            is ActionStep.BobDraft -> ActionResult(false, ExecutionMethod.NONE, "handled by engine")
        }
        if (intentAttempt.success) return intentAttempt

        if (step is ActionStep.NotificationReply) {
            val notif = AutopilotNotificationListener.instance?.reply(
                step.packageName,
                step.text,
                step.keyContains,
            )
            if (notif?.success == true) return notif
        } else {
            val notifFallback = notificationFallback(step)
            if (notifFallback.success) return notifFallback
        }

        val macro = when (step) {
            is ActionStep.UiMacro -> accessibility.run(step.steps)
            is ActionStep.OpenApp -> accessibility.run(
                listOf(UiGesture.Wait(200)) + launchThenWait(step.packageName),
            )
            is ActionStep.DeepLink -> {
                deepLink(step.uri, step.packageName)
                accessibility.run(listOf(UiGesture.Wait(400)))
            }
            is ActionStep.NotificationReply -> accessibility.run(
                listOf(
                    UiGesture.TapText("Reply"),
                    UiGesture.Wait(250),
                    UiGesture.Type(step.text),
                    UiGesture.TapText("Send"),
                ),
            )
            else -> ActionResult(false, ExecutionMethod.ACCESSIBILITY, intentAttempt.detail)
        }
        return if (macro.success) macro else ActionResult(
            false,
            ExecutionMethod.NONE,
            "All fallbacks failed: ${intentAttempt.detail} / ${macro.detail}",
        )
    }

    override suspend fun runMacro(steps: List<UiGesture>): ActionResult = accessibility.run(steps)

    override suspend fun announce(title: String, detail: String) {
        overlay.ensureShown()
        hud.show(title, detail, takeover = true)
    }

    override suspend fun abortTakeover() {
        accessibility.abort()
        hud.hide()
    }

    private fun launchThenWait(packageName: String): List<UiGesture> {
        openApp(packageName)
        return listOf(UiGesture.Wait(600))
    }

    private fun call(number: String): ActionResult {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return ActionResult(false, ExecutionMethod.INTENT, "CALL_PHONE denied")
        }
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return launch(intent, "CALL $number")
    }

    private fun sms(number: String, message: String): ActionResult {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return ActionResult(false, ExecutionMethod.INTENT, "SEND_SMS denied")
        }
        return runCatching {
            SmsManager.getDefault().sendTextMessage(number, null, message, null, null)
            ActionResult(true, ExecutionMethod.INTENT, "SMS queued")
        }.getOrElse { ActionResult(false, ExecutionMethod.INTENT, it.message ?: "sms fail") }
    }

    private fun deepLink(uri: String, packageName: String?): ActionResult = runCatching {
        val intent = Intent.parseUri(uri, Intent.URI_INTENT_SCHEME).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (!packageName.isNullOrBlank()) setPackage(packageName)
        }
        launch(intent, "DEEPLINK $uri")
    }.getOrElse { ActionResult(false, ExecutionMethod.INTENT, it.message ?: "deeplink fail") }

    private fun openApp(packageName: String): ActionResult {
        val launch = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: return ActionResult(false, ExecutionMethod.INTENT, "No launcher for $packageName")
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return launch(launch, "OPEN $packageName")
    }

    private fun launch(intent: Intent, label: String): ActionResult = runCatching {
        context.startActivity(intent)
        ActionResult(true, ExecutionMethod.INTENT, label)
    }.getOrElse { ActionResult(false, ExecutionMethod.INTENT, it.message ?: "intent fail") }

    private fun notificationFallback(step: ActionStep): ActionResult {
        if (step !is ActionStep.Sms) return ActionResult(false, ExecutionMethod.NOTIFICATION, "n/a")
        return AutopilotNotificationListener.instance?.reply("com.google.android.apps.messaging", step.message, step.number)
            ?: ActionResult(false, ExecutionMethod.NOTIFICATION, "listener offline")
    }
}
