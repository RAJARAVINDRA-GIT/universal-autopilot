package com.universal.autopilot.platform.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.universal.autopilot.core.model.ActionResult
import com.universal.autopilot.core.model.ExecutionMethod
import com.universal.autopilot.core.model.UiGesture
import kotlinx.coroutines.delay
import timber.log.Timber

class AutopilotAccessibilityService : AccessibilityService() {

    @Volatile
    var lastPackage: String? = null
        private set

    var abortRequested: Boolean = false
        private set

    override fun onServiceConnected() {
        instance = this
        Timber.i("BOB accessibility link online")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        lastPackage = pkg
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            AppLifecycleBridge.onWindow(pkg, true)
        }
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun abort() {
        abortRequested = true
    }

    suspend fun perform(steps: List<UiGesture>): ActionResult {
        abortRequested = false
        steps.forEachIndexed { index, step ->
            if (abortRequested) {
                return ActionResult(false, ExecutionMethod.ACCESSIBILITY, "Aborted at $index")
            }
            val ok = when (step) {
                is UiGesture.Tap -> tap(step.x, step.y)
                is UiGesture.TapText -> clickText(step.text)
                is UiGesture.Type -> type(step.text)
                is UiGesture.Scroll -> scroll(step.down)
                is UiGesture.Wait -> {
                    delay(step.millis)
                    true
                }
                UiGesture.Back -> performGlobalAction(GLOBAL_ACTION_BACK)
                UiGesture.Home -> performGlobalAction(GLOBAL_ACTION_HOME)
                is UiGesture.ClickViewId -> clickId(step.viewId)
            }
            if (!ok) {
                return ActionResult(false, ExecutionMethod.ACCESSIBILITY, "Gesture failed: $step")
            }
            delay(180)
        }
        return ActionResult(true, ExecutionMethod.ACCESSIBILITY, "Macro complete")
    }

    private fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    private fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(text)
        val target = nodes.firstOrNull { it.isClickable } ?: nodes.firstOrNull()?.clickableParent()
        return target?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
    }

    private fun clickId(id: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByViewId(id)
        return nodes.firstOrNull()?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
    }

    private fun type(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun scroll(down: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val action = if (down) {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        } else {
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        }
        return findScrollable(root)?.performAction(action) == true
    }

    private fun findScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findScrollable(child)
            if (found != null) return found
        }
        return null
    }

    private fun AccessibilityNodeInfo.clickableParent(): AccessibilityNodeInfo? {
        var current: AccessibilityNodeInfo? = this
        while (current != null) {
            if (current.isClickable) return current
            current = current.parent
        }
        return null
    }

    companion object {
        @Volatile
        var instance: AutopilotAccessibilityService? = null
            private set
    }
}
