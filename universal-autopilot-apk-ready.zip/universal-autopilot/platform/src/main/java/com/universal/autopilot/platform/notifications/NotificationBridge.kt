package com.universal.autopilot.platform.notifications

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch

data class PostedNotification(
    val key: String,
    val packageName: String,
    val title: String,
    val text: String,
    val canReply: Boolean,
)

object NotificationBridge {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _events = MutableSharedFlow<PostedNotification>(extraBufferCapacity = 64)
    val events: SharedFlow<PostedNotification> = _events

    fun onPosted(key: String, packageName: String, title: String, text: String, canReply: Boolean) {
        scope.launch {
            _events.emit(PostedNotification(key, packageName, title, text, canReply))
        }
    }
}
