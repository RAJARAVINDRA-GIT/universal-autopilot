package com.universal.autopilot.platform.accessibility

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch

object AppLifecycleBridge {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _events = MutableSharedFlow<Pair<String, Boolean>>(extraBufferCapacity = 32)
    val events: SharedFlow<Pair<String, Boolean>> = _events

    fun onWindow(packageName: String, opened: Boolean) {
        scope.launch { _events.emit(packageName to opened) }
    }
}
