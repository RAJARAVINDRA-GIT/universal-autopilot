package com.universal.autopilot.platform.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.universal.autopilot.core.ui.theme.AutopilotTheme
import com.universal.autopilot.core.ui.theme.Cyan
import com.universal.autopilot.core.ui.theme.Magenta
import com.universal.autopilot.core.ui.theme.Void
import com.universal.autopilot.platform.accessibility.AccessibilityCommandBus
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class OverlayManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val hud: HudController,
    private val bus: AccessibilityCommandBus,
) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var view: ComposeView? = null

    fun canDraw(): Boolean = Settings.canDrawOverlays(context)

    fun ensureShown() {
        if (!canDraw() || view != null) return
        val compose = ComposeView(context).apply {
            setViewTreeLifecycleOwner(OverlayLifecycleOwner)
            setViewTreeViewModelStoreOwner(OverlayLifecycleOwner)
            setViewTreeSavedStateRegistryOwner(OverlayLifecycleOwner)
            OverlayLifecycleOwner.attach()
            setContent {
                val state by hud.state.collectAsState()
                if (state.visible) {
                    AutopilotTheme {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                                .background(
                                    Brush.horizontalGradient(listOf(Void.copy(alpha = 0.92f), Color(0xE6101828))),
                                    RoundedCornerShape(16.dp),
                                )
                                .border(1.dp, if (state.takeover) Magenta else Cyan, RoundedCornerShape(16.dp))
                                .padding(14.dp),
                        ) {
                            Text("◢ BOB HUD", color = Cyan, fontSize = 12.sp, letterSpacing = 3.sp)
                            Text(state.title, color = Color.White, fontSize = 16.sp)
                            Text(state.detail, color = Cyan.copy(alpha = 0.85f), fontSize = 12.sp)
                            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                                TextButton(onClick = {
                                    bus.abort()
                                    hud.hide()
                                }) {
                                    Text("ABORT TAKEOVER", color = Magenta)
                                }
                            }
                        }
                    }
                }
            }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP
            y = 24
        }
        runCatching { wm.addView(compose, params) }
        view = compose
        scope.launch { hud.state.collect { /* recomposes via state */ } }
    }

    fun remove() {
        view?.let { runCatching { wm.removeView(it) } }
        view = null
    }
}
