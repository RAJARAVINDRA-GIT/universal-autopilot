package com.universal.autopilot.platform.di

import com.universal.autopilot.engine.DeviceActionGateway
import com.universal.autopilot.platform.actions.FallbackDeviceGateway
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class PlatformModule {
    @Binds
    @Singleton
    abstract fun devices(impl: FallbackDeviceGateway): DeviceActionGateway
}
