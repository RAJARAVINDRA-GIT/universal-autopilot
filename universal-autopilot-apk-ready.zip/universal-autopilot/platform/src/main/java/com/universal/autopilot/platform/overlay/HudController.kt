package com.universal.autopilot.platform.overlay

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

data class HudState(
    val visible: Boolean = false,
    val title: String = "BOB STANDBY",
    val detail: String = "Neural overlay idle.",
    val takeover: Boolean = false,
)

@Singleton
class HudController @Inject constructor() {
    private val _state = MutableStateFlow(HudState())
    val state: StateFlow<HudState> = _state.asStateFlow()

    fun show(title: String, detail: String, takeover: Boolean = true) {
        _state.value = HudState(visible = true, title = title, detail = detail, takeover = takeover)
    }

    fun hide() {
        _state.value = _state.value.copy(visible = false, takeover = false, title = "BOB STANDBY")
    }
}
