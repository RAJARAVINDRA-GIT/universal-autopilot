package com.universal.autopilot.platform.accessibility

import com.universal.autopilot.core.model.ActionResult
import com.universal.autopilot.core.model.ExecutionMethod
import com.universal.autopilot.core.model.UiGesture
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.channels.Channel
import javax.inject.Inject
import javax.inject.Singleton

sealed interface UiCommand {
    data class Gestures(
        val steps: List<UiGesture>,
        val result: CompletableDeferred<ActionResult>,
    ) : UiCommand

    data object Abort : UiCommand
}

@Singleton
class AccessibilityCommandBus @Inject constructor() {
    val commands = Channel<UiCommand>(Channel.BUFFERED)

    suspend fun run(steps: List<UiGesture>): ActionResult {
        val service = AutopilotAccessibilityService.instance
            ?: return ActionResult(false, ExecutionMethod.ACCESSIBILITY, "Enable BOB accessibility service")
        return service.perform(steps)
    }

    fun abort() {
        AutopilotAccessibilityService.instance?.abort()
        commands.trySend(UiCommand.Abort)
    }
}
