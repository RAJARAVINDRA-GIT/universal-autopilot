package com.universal.autopilot.di

import com.universal.autopilot.bob.BobBrain
import com.universal.autopilot.engine.BobGateway
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class BobBindModule {
    @Binds
    @Singleton
    abstract fun bob(impl: BobBrain): BobGateway
}

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {
    @Provides
    @Singleton
    fun http(): OkHttpClient = OkHttpClient.Builder()
        .callTimeout(40, TimeUnit.SECONDS)
        .build()
}
