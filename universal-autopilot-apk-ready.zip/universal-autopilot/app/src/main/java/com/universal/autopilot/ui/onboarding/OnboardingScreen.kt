package com.universal.autopilot.ui.onboarding

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.universal.autopilot.core.ui.components.CyberBackdrop
import com.universal.autopilot.core.ui.components.GlassPanel
import com.universal.autopilot.core.ui.theme.Cyan
import com.universal.autopilot.core.ui.theme.Magenta

@Composable
fun OnboardingScreen(onContinue: () -> Unit) {
    CyberBackdrop {
        Column(Modifier.fillMaxSize().padding(24.dp)) {
            Text("AUTOPILOT v2", color = Cyan, fontSize = 32.sp, letterSpacing = 4.sp)
            Text("BOB is coming online.", color = Magenta)
            Spacer(Modifier.height(20.dp))
            GlassPanel {
                Text("This device will run a persistent HUD over other apps.")
                Spacer(Modifier.height(8.dp))
                Text("WHEN a trigger fires, BOB executes DO actions unless UNLESS guards block them.")
                Spacer(Modifier.height(8.dp))
                Text("Fallback order: intents → notification RemoteInput → accessibility gestures.")
                Spacer(Modifier.height(8.dp))
                Text("Drafts never send until you approve them in the BOB console.")
            }
            Spacer(Modifier.height(24.dp))
            Button(onClick = onContinue, modifier = Modifier.fillMaxWidth()) {
                Text("ARM BOB")
            }
        }
    }
}
