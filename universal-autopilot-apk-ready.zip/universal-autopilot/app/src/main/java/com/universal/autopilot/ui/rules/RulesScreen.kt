package com.universal.autopilot.ui.rules

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.universal.autopilot.core.ui.components.CyberBackdrop
import com.universal.autopilot.core.ui.components.GlassPanel
import com.universal.autopilot.core.ui.theme.Cyan
import com.universal.autopilot.core.ui.theme.Void

@Composable
fun RulesScreen(
    onEdit: (String?) -> Unit,
    vm: RuleListViewModel = hiltViewModel(),
) {
    val rules by vm.rules.collectAsState(initial = emptyList())
    CyberBackdrop {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("WHEN → DO → UNLESS", color = Cyan)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                items(rules, key = { it.id }) { rule ->
                    GlassPanel(modifier = Modifier.clickable { onEdit(rule.id) }) {
                        Text(rule.name, color = Cyan)
                        Text("WHEN ${rule.trigger::class.simpleName}")
                        Text("DO ${rule.actions.joinToString { it::class.simpleName ?: "" }}")
                        Text("UNLESS ${rule.unless.size} guards")
                    }
                }
            }
            FloatingActionButton(
                onClick = { onEdit(null) },
                containerColor = Cyan,
                contentColor = Void,
                modifier = Modifier.align(Alignment.End),
            ) { Text("+") }
        }
    }
}
