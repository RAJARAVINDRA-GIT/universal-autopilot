package com.universal.autopilot.ui.dashboard

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.universal.autopilot.core.ui.components.CyberBackdrop
import com.universal.autopilot.core.ui.components.GlassPanel
import com.universal.autopilot.core.ui.theme.Amber
import com.universal.autopilot.core.ui.theme.Cyan
import com.universal.autopilot.core.ui.theme.Magenta

@Composable
fun DashboardScreen(
    onRules: () -> Unit,
    onBob: () -> Unit,
    onSettings: () -> Unit,
    onEdit: (String) -> Unit,
    vm: DashboardViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsState()
    CyberBackdrop {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("AUTOPILOT v2", color = Cyan, fontSize = 28.sp, letterSpacing = 3.sp)
            Text("BOB neural overlay · universal app actions", color = Magenta, fontSize = 12.sp)
            Spacer(Modifier.height(16.dp))
            GlassPanel {
                Text("CONTROL DECK", color = Amber, fontSize = 11.sp, letterSpacing = 2.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = onBob) { Text("TALK TO BOB", color = Cyan) }
                    TextButton(onClick = onRules) { Text("RULES", color = Cyan) }
                    TextButton(onClick = onSettings) { Text("LINK", color = Cyan) }
                }
            }
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(state.rules, key = { it.id }) { rule ->
                    GlassPanel(modifier = Modifier.clickable { onEdit(rule.id) }) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text(rule.name, color = Cyan)
                                Text("${rule.trigger::class.simpleName} · ${rule.actions.size} actions", fontSize = 12.sp)
                            }
                            Switch(checked = rule.enabled, onCheckedChange = { vm.toggle(rule) })
                        }
                        TextButton(onClick = { vm.runNow(rule) }) { Text("EXECUTE NOW", color = Magenta) }
                    }
                }
                item {
                    GlassPanel(accentMagenta = true) {
                        Text("MISSION LOG", color = Magenta, fontSize = 11.sp, letterSpacing = 2.sp)
                        state.logs.take(8).forEach {
                            Text("${it.status} · ${it.ruleName} · ${it.message}", fontSize = 12.sp, color = Cyan)
                        }
                    }
                }
            }
        }
    }
}
