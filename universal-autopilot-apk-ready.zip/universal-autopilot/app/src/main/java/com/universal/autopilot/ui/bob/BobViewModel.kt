package com.universal.autopilot.ui.bob

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.universal.autopilot.bob.BobBrain
import com.universal.autopilot.core.data.RuleRepository
import com.universal.autopilot.core.data.RuntimeRepository
import com.universal.autopilot.core.model.ActionStep
import com.universal.autopilot.core.model.AutomationRule
import com.universal.autopilot.core.model.BobMessage
import com.universal.autopilot.core.model.BobRole
import com.universal.autopilot.core.model.DraftChannel
import com.universal.autopilot.core.model.PendingDraft
import com.universal.autopilot.engine.DeviceActionGateway
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

@HiltViewModel
class BobViewModel @Inject constructor(
    private val runtime: RuntimeRepository,
    private val bob: BobBrain,
    private val rules: RuleRepository,
    private val devices: DeviceActionGateway,
) : ViewModel() {
    val chat = runtime.observeChat().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val drafts = runtime.observeDrafts().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun send(text: String) {
        viewModelScope.launch {
            runtime.addChat(BobMessage(UUID.randomUUID().toString(), BobRole.USER, text))
            val history = chat.value
            val reply = if (text.startsWith("/rule", true)) {
                bob.parseRule(text.removePrefix("/rule")).getOrNull()?.let { draft ->
                    rules.save(
                        AutomationRule(
                            name = draft.name,
                            trigger = draft.trigger,
                            actions = draft.actions,
                            unless = draft.unless,
                        ),
                    )
                    "Directive locked: ${draft.name}. BOB will fire it when the WHEN matches."
                } ?: "Could not parse rule."
            } else if (text.startsWith("/sum", true)) {
                val pkg = text.substringAfter(" ").ifBlank { "com.whatsapp" }
                bob.summarizePackage(pkg.trim())
            } else {
                bob.chat(history, text)
            }
            runtime.addChat(BobMessage(UUID.randomUUID().toString(), BobRole.BOB, reply))
        }
    }

    fun approve(draft: PendingDraft) {
        viewModelScope.launch {
            val step = when (draft.channel) {
                DraftChannel.SMS -> ActionStep.Sms(number = draft.number.orEmpty(), message = draft.body)
                DraftChannel.NOTIFICATION -> ActionStep.NotificationReply(
                    packageName = draft.packageName.orEmpty(),
                    text = draft.body,
                )
                DraftChannel.DEEPLINK -> ActionStep.DeepLink(uri = draft.body)
            }
            devices.execute(step)
            runtime.deleteDraft(draft.id)
            runtime.addChat(BobMessage(UUID.randomUUID().toString(), BobRole.BOB, "Transmit approved."))
        }
    }

    fun reject(id: String) {
        viewModelScope.launch { runtime.deleteDraft(id) }
    }
}
