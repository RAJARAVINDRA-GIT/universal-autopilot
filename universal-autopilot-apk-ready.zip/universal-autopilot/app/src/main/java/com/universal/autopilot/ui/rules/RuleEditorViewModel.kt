package com.universal.autopilot.ui.rules

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.universal.autopilot.core.data.RuleRepository
import com.universal.autopilot.core.model.ActionStep
import com.universal.autopilot.core.model.AutomationRule
import com.universal.autopilot.core.model.RetryPolicy
import com.universal.autopilot.core.model.Trigger
import com.universal.autopilot.core.model.UnlessCondition
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class RuleEditorViewModel @Inject constructor(
    private val repo: RuleRepository,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {
    private val existingId: String? = savedStateHandle.get<String>("ruleId")?.ifBlank { null }
    private val _rule = MutableStateFlow(
        AutomationRule(
            name = "New directive",
            trigger = Trigger.Notification(packageName = "com.whatsapp"),
            actions = listOf(ActionStep.BobDraft(instruction = "Draft a short reply")),
            unless = listOf(UnlessCondition.BatteryBelow(12)),
            retry = RetryPolicy(),
        ),
    )
    val rule = _rule.asStateFlow()

    init {
        existingId?.let { id ->
            viewModelScope.launch { repo.get(id)?.let { _rule.value = it } }
        }
    }

    fun update(block: (AutomationRule) -> AutomationRule) {
        _rule.value = block(_rule.value)
    }

    fun save(onDone: () -> Unit) {
        viewModelScope.launch {
            repo.save(_rule.value)
            onDone()
        }
    }

    fun delete(onDone: () -> Unit) {
        viewModelScope.launch {
            repo.delete(_rule.value.id)
            onDone()
        }
    }
}

@HiltViewModel
class RuleListViewModel @Inject constructor(
    repo: RuleRepository,
) : ViewModel() {
    val rules = repo.observeRules()
}
