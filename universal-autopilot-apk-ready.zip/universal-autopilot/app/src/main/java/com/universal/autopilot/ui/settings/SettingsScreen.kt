package com.universal.autopilot.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.universal.autopilot.core.data.SettingsRepository
import com.universal.autopilot.core.ui.components.CyberBackdrop
import com.universal.autopilot.core.ui.components.GlassPanel
import com.universal.autopilot.core.ui.theme.Cyan
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val repo: SettingsRepository,
) : ViewModel() {
    val settings = repo.settings
    fun save(endpoint: String, model: String, key: String, takeover: Boolean) {
        viewModelScope.launch {
            repo.setBobConfig(endpoint, model, key.ifBlank { null })
            repo.setTakeover(takeover)
        }
    }
}

@Composable
fun SettingsScreen(vm: SettingsViewModel = hiltViewModel()) {
    val settings by vm.settings.collectAsState(
        initial = com.universal.autopilot.core.data.AutopilotSettings(false, true, "", "gpt-4o-mini", false),
    )
    var endpoint by remember(settings.bobEndpoint) { mutableStateOf(settings.bobEndpoint) }
    var model by remember(settings.bobModel) { mutableStateOf(settings.bobModel) }
    var key by remember { mutableStateOf("") }
    val context = LocalContext.current
    CyberBackdrop {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("UPLINK / PERMISSIONS", color = Cyan)
            Spacer(Modifier.height(12.dp))
            GlassPanel {
                OutlinedTextField(endpoint, { endpoint = it }, label = { Text("BOB endpoint") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(model, { model = it }, label = { Text("Model") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(key, { key = it }, label = { Text("API key (encrypted)") }, modifier = Modifier.fillMaxWidth())
                Text("Takeover HUD")
                Switch(checked = settings.takeoverEnabled, onCheckedChange = {
                    vm.save(endpoint, model, key, it)
                })
                Button(onClick = { vm.save(endpoint, model, key, settings.takeoverEnabled) }, modifier = Modifier.fillMaxWidth()) {
                    Text("SAVE BOB CONFIG")
                }
            }
            Spacer(Modifier.height(12.dp))
            GlassPanel {
                Button(onClick = {
                    context.startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}"),
                        ),
                    )
                }, modifier = Modifier.fillMaxWidth()) { Text("DISPLAY OVER OTHER APPS") }
                Button(onClick = {
                    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }, modifier = Modifier.fillMaxWidth()) { Text("ACCESSIBILITY · BOB") }
                Button(onClick = {
                    context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }, modifier = Modifier.fillMaxWidth()) { Text("NOTIFICATION ACCESS") }
                Button(onClick = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("IGNORE BATTERY OPTIMIZATION") }
            }
        }
    }
}
