package com.universal.autopilot.ui.nav

sealed class Route(val path: String) {
    data object Onboarding : Route("onboarding")
    data object Dashboard : Route("dashboard")
    data object Rules : Route("rules")
    data object Editor : Route("editor?ruleId={ruleId}") {
        fun of(id: String?) = "editor?ruleId=${id.orEmpty()}"
    }
    data object Bob : Route("bob")
    data object Settings : Route("settings")
    data object Permissions : Route("permissions")
}
