package com.universal.autopilot.service

import android.app.PendingIntent
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.universal.autopilot.MainActivity
import com.universal.autopilot.R
import com.universal.autopilot.core.common.AutopilotIds
import com.universal.autopilot.core.data.NotificationInbox
import com.universal.autopilot.engine.RuleEngine
import com.universal.autopilot.platform.accessibility.AppLifecycleBridge
import com.universal.autopilot.platform.notifications.NotificationBridge
import com.universal.autopilot.platform.overlay.HudController
import com.universal.autopilot.platform.overlay.OverlayManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalTime
import java.time.ZonedDateTime
import javax.inject.Inject

@AndroidEntryPoint
class AutopilotService : LifecycleService() {

    @Inject lateinit var engine: RuleEngine
    @Inject lateinit var inbox: NotificationInbox
    @Inject lateinit var overlay: OverlayManager
    @Inject lateinit var hud: HudController

    private var wifiCallback: ConnectivityManager.NetworkCallback? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(AutopilotIds.FOREGROUND_ID, persistent())
        overlay.ensureShown()
        hud.show("BOB ONLINE", "Background autopilot armed.", takeover = false)
        lifecycleScope.launch {
            NotificationBridge.events.collect { event ->
                inbox.capture(event.key, event.packageName, event.title, event.text, event.canReply)
                engine.onNotification(event.packageName, event.title, event.text)
            }
        }
        lifecycleScope.launch {
            AppLifecycleBridge.events.collect { (pkg, opened) ->
                engine.onApp(pkg, opened)
            }
        }
        lifecycleScope.launch {
            while (true) {
                val now = LocalTime.now()
                engine.onSchedule(now.hour, now.minute, ZonedDateTime.now().dayOfWeek.value)
                engine.processRetries()
                delay(30_000)
            }
        }
        registerWifi()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        overlay.ensureShown()
        return START_STICKY
    }

    override fun onDestroy() {
        wifiCallback?.let {
            getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it)
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }

    private fun registerWifi() {
        val cm = getSystemService(ConnectivityManager::class.java)
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                val ssid = getSystemService(WifiManager::class.java).connectionInfo?.ssid?.trim('"')
                lifecycleScope.launch { engine.onWifi(ssid) }
            }
        }
        wifiCallback = callback
        cm.registerNetworkCallback(
            NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build(),
            callback,
        )
    }

    private fun persistent() = NotificationCompat.Builder(this, AutopilotIds.CHANNEL_CORE)
        .setSmallIcon(R.drawable.ic_bob)
        .setContentTitle("BOB autopilot")
        .setContentText("Phone control link is live.")
        .setOngoing(true)
        .setContentIntent(
            PendingIntent.getActivity(
                this,
                0,
                Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            ),
        )
        .build()
}
