package com.universal.autopilot.ui.rules

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.universal.autopilot.core.model.ActionStep
import com.universal.autopilot.core.model.Trigger
import com.universal.autopilot.core.model.UnlessCondition
import com.universal.autopilot.core.ui.components.CyberBackdrop
import com.universal.autopilot.core.ui.components.GlassPanel
import com.universal.autopilot.core.ui.theme.Cyan
import com.universal.autopilot.core.ui.theme.Magenta

@Composable
fun RuleEditorScreen(
    onDone: () -> Unit,
    vm: RuleEditorViewModel = hiltViewModel(),
) {
    val rule by vm.rule.collectAsState()
    val pkg = (rule.trigger as? Trigger.Notification)?.packageName
        ?: (rule.trigger as? Trigger.AppLifecycle)?.packageName
        ?: ""
    CyberBackdrop {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
        ) {
            Text("FORGE DIRECTIVE", color = Cyan)
            Spacer(Modifier.height(12.dp))
            GlassPanel {
                OutlinedTextField(
                    value = rule.name,
                    onValueChange = { v -> vm.update { it.copy(name = v) } },
                    label = { Text("Name") },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Spacer(Modifier.height(10.dp))
            GlassPanel {
                Text("WHEN", color = Cyan)
                OutlinedTextField(
                    value = pkg,
                    onValueChange = { v ->
                        vm.update { it.copy(trigger = Trigger.Notification(packageName = v)) }
                    },
                    label = { Text("Trigger package") },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Spacer(Modifier.height(10.dp))
            GlassPanel {
                Text("DO", color = Cyan)
                rule.actions.forEach { step ->
                    Text(step::class.simpleName + " " + describe(step))
                }
                TextButton(onClick = {
                    vm.update {
                        it.copy(actions = it.actions + ActionStep.OpenApp(packageName = pkg.ifBlank { "com.whatsapp" }))
                    }
                }) { Text("ADD OPEN APP", color = Cyan) }
                TextButton(onClick = {
                    vm.update {
                        it.copy(actions = it.actions + ActionStep.Call(number = "+10000000000"))
                    }
                }) { Text("ADD CALL", color = Cyan) }
                TextButton(onClick = {
                    vm.update {
                        it.copy(
                            actions = it.actions + ActionStep.NotificationReply(
                                packageName = pkg.ifBlank { "com.whatsapp" },
                                text = "On my way.",
                            ),
                        )
                    }
                }) { Text("ADD NOTIF REPLY", color = Cyan) }
            }
            Spacer(Modifier.height(10.dp))
            GlassPanel(accentMagenta = true) {
                Text("UNLESS", color = Magenta)
                TextButton(onClick = {
                    vm.update { it.copy(unless = it.unless + UnlessCondition.NoWifi) }
                }) { Text("NO WIFI", color = Magenta) }
                TextButton(onClick = {
                    vm.update { it.copy(unless = it.unless + UnlessCondition.DeviceLocked) }
                }) { Text("DEVICE LOCKED", color = Magenta) }
                rule.unless.forEach { Text(it.toString()) }
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = { vm.save(onDone) }, modifier = Modifier.fillMaxWidth()) {
                Text("COMMIT RULE")
            }
            TextButton(onClick = { vm.delete(onDone) }) { Text("DELETE", color = Magenta) }
        }
    }
}

private fun describe(step: ActionStep): String = when (step) {
    is ActionStep.Call -> step.number
    is ActionStep.Sms -> "${step.number}: ${step.message}"
    is ActionStep.DeepLink -> step.uri
    is ActionStep.OpenApp -> step.packageName
    is ActionStep.NotificationReply -> step.text
    is ActionStep.UiMacro -> "${step.steps.size} gestures"
    is ActionStep.BobDraft -> step.instruction
}
