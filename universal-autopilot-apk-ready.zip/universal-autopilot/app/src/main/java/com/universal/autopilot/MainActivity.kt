package com.universal.autopilot

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.lifecycle.lifecycleScope
import com.universal.autopilot.core.data.RuleRepository
import com.universal.autopilot.core.data.SettingsRepository
import com.universal.autopilot.core.model.ActionStep
import com.universal.autopilot.core.model.AutomationRule
import com.universal.autopilot.core.model.Trigger
import com.universal.autopilot.core.model.UnlessCondition
import com.universal.autopilot.core.ui.theme.AutopilotTheme
import com.universal.autopilot.service.AutopilotService
import com.universal.autopilot.ui.bob.BobScreen
import com.universal.autopilot.ui.dashboard.DashboardScreen
import com.universal.autopilot.ui.nav.Route
import com.universal.autopilot.ui.onboarding.OnboardingScreen
import com.universal.autopilot.ui.rules.RuleEditorScreen
import com.universal.autopilot.ui.rules.RulesScreen
import com.universal.autopilot.ui.settings.SettingsScreen
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var settings: SettingsRepository
    @Inject lateinit var rules: RuleRepository

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { startAutopilot() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestCorePermissions()
        setContent {
            AutopilotTheme {
                val nav = rememberNavController()
                val prefs by settings.settings.collectAsState(
                    initial = com.universal.autopilot.core.data.AutopilotSettings(
                        onboarded = false,
                        takeoverEnabled = true,
                        bobEndpoint = "",
                        bobModel = "gpt-4o-mini",
                        hasApiKey = false,
                    ),
                )
                val start = if (prefs.onboarded) Route.Dashboard.path else Route.Onboarding.path
                NavHost(navController = nav, startDestination = start) {
                    composable(Route.Onboarding.path) {
                        OnboardingScreen {
                            lifecycleScope.launch {
                                settings.setOnboarded()
                                seed()
                            }
                            nav.navigate(Route.Dashboard.path) { popUpTo(Route.Onboarding.path) { inclusive = true } }
                        }
                    }
                    composable(Route.Dashboard.path) {
                        DashboardScreen(
                            onRules = { nav.navigate(Route.Rules.path) },
                            onBob = { nav.navigate(Route.Bob.path) },
                            onSettings = { nav.navigate(Route.Settings.path) },
                            onEdit = { id -> nav.navigate(Route.Editor.of(id)) },
                        )
                    }
                    composable(Route.Rules.path) {
                        RulesScreen(onEdit = { nav.navigate(Route.Editor.of(it)) })
                    }
                    composable(
                        route = "editor?ruleId={ruleId}",
                        arguments = listOf(
                            navArgument("ruleId") {
                                type = NavType.StringType
                                nullable = true
                                defaultValue = null
                            },
                        ),
                    ) {
                        RuleEditorScreen(onDone = { nav.popBackStack() })
                    }
                    composable(Route.Bob.path) { BobScreen() }
                    composable(Route.Settings.path) { SettingsScreen() }
                }
                LaunchedEffect(Unit) { startAutopilot() }
            }
        }
    }

    private fun requestCorePermissions() {
        val needed = buildList {
            add(Manifest.permission.CALL_PHONE)
            add(Manifest.permission.SEND_SMS)
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
            add(Manifest.permission.READ_PHONE_STATE)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.toTypedArray()
        permissionLauncher.launch(needed)
    }

    private fun startAutopilot() {
        ContextCompat.startForegroundService(this, Intent(this, AutopilotService::class.java))
    }

    private suspend fun seed() {
        if (rules.enabledRules().isNotEmpty()) return
        rules.save(
            AutomationRule(
                name = "WhatsApp triage via BOB",
                trigger = Trigger.Notification(packageName = "com.whatsapp"),
                actions = listOf(
                    ActionStep.BobDraft(
                        instruction = "Draft a calm reply. Do not send.",
                        packageName = "com.whatsapp",
                    ),
                ),
                unless = listOf(UnlessCondition.BatteryBelow(10)),
            ),
        )
    }
}
