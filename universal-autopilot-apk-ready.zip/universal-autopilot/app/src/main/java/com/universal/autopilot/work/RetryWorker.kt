package com.universal.autopilot.work

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.universal.autopilot.engine.RuleEngine
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject

@HiltWorker
class RetryWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val engine: RuleEngine,
) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        engine.processRetries()
        return Result.success()
    }
}
