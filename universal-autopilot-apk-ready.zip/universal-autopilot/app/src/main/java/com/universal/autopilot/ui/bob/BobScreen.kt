package com.universal.autopilot.ui.bob

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.universal.autopilot.core.model.BobRole
import com.universal.autopilot.core.ui.components.CyberBackdrop
import com.universal.autopilot.core.ui.components.GlassPanel
import com.universal.autopilot.core.ui.theme.Cyan
import com.universal.autopilot.core.ui.theme.Magenta

@Composable
fun BobScreen(vm: BobViewModel = hiltViewModel()) {
    val chat by vm.chat.collectAsState()
    val drafts by vm.drafts.collectAsState()
    var input by remember { mutableStateOf("") }
    CyberBackdrop {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text("BOB // NEURAL LINK", color = Cyan)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(drafts) { draft ->
                    GlassPanel(accentMagenta = true) {
                        Text("PENDING TRANSMIT", color = Magenta)
                        Text(draft.body)
                        Row {
                            TextButton(onClick = { vm.approve(draft) }) { Text("APPROVE", color = Cyan) }
                            TextButton(onClick = { vm.reject(draft.id) }) { Text("SCRUB", color = Magenta) }
                        }
                    }
                }
                items(chat) { msg ->
                    GlassPanel(accentMagenta = msg.role == BobRole.USER) {
                        Text(if (msg.role == BobRole.BOB) "BOB" else "YOU", color = Cyan)
                        Text(msg.content)
                    }
                }
            }
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("/rule · /sum com.whatsapp · or talk") },
            )
            Button(
                onClick = {
                    vm.send(input)
                    input = ""
                },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            ) { Text("UPLINK") }
        }
    }
}
