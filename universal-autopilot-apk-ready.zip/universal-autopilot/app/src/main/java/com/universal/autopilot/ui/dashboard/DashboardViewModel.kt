package com.universal.autopilot.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.universal.autopilot.core.data.RuntimeRepository
import com.universal.autopilot.core.data.RuleRepository
import com.universal.autopilot.core.data.SettingsRepository
import com.universal.autopilot.core.model.AutomationRule
import com.universal.autopilot.core.model.ExecutionRecord
import com.universal.autopilot.engine.ActionRunner
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DashboardState(
    val rules: List<AutomationRule> = emptyList(),
    val logs: List<ExecutionRecord> = emptyList(),
    val takeover: Boolean = true,
)

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val rules: RuleRepository,
    runtime: RuntimeRepository,
    private val settings: SettingsRepository,
    private val runner: ActionRunner,
) : ViewModel() {
    val state = combine(rules.observeRules(), runtime.observeExecutions(), settings.settings) { r, l, s ->
        DashboardState(r, l, s.takeoverEnabled)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DashboardState())

    fun toggle(rule: AutomationRule) {
        viewModelScope.launch { rules.save(rule.copy(enabled = !rule.enabled)) }
    }

    fun runNow(rule: AutomationRule) {
        viewModelScope.launch { runner.run(rule, force = true) }
    }
}
