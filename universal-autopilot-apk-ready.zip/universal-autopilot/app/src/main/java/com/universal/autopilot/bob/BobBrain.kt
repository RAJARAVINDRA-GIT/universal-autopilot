package com.universal.autopilot.bob

import com.universal.autopilot.core.data.NotificationInbox
import com.universal.autopilot.core.data.SettingsRepository
import com.universal.autopilot.core.model.ActionStep
import com.universal.autopilot.core.model.BehaviorSignal
import com.universal.autopilot.core.model.BobMessage
import com.universal.autopilot.core.model.BobRole
import com.universal.autopilot.core.model.RuleDraft
import com.universal.autopilot.core.model.Trigger
import com.universal.autopilot.engine.BobGateway
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BobBrain @Inject constructor(
    private val settings: SettingsRepository,
    private val inbox: NotificationInbox,
    private val json: Json,
    private val http: OkHttpClient,
) : BobGateway {

    override suspend fun draft(instruction: String, context: String): String {
        val prompt = "Draft a concise message. Instruction: $instruction Context: $context"
        return complete(prompt, fallback = heuristicDraft(instruction))
    }

    override suspend fun summarize(thread: String): String {
        if (thread.isBlank()) return "No captured thread yet. BOB needs notification access."
        return complete("Summarize this thread for the user:\n$thread", fallback = heuristicSummary(thread))
    }

    override suspend fun parseRule(utterance: String): Result<RuleDraft> = runCatching {
        val remote = complete(
            "Convert this automation into JSON with keys name, triggerType, details. Utterance: $utterance",
            fallback = "",
        )
        if (remote.isNotBlank() && remote.contains("{")) {
            heuristicParse(utterance)
        } else heuristicParse(utterance)
    }

    override suspend fun chat(history: List<BobMessage>, user: String): String {
        val transcript = history.takeLast(12).joinToString("\n") { "${it.role}: ${it.content}" }
        return complete(
            "You are BOB, a cyber HUD autopilot for Android. Be terse, tactical, never claim you sent a message without approval.\n$transcript\nUSER: $user",
            fallback = localChat(user),
        )
    }

    override suspend fun suggest(signals: List<BehaviorSignal>): List<RuleDraft> {
        val top = signals.groupingBy { it.packageName }.eachCount().maxByOrNull { it.value }?.key ?: return emptyList()
        return listOf(
            RuleDraft(
                name = "BOB: auto-triage $top",
                trigger = Trigger.Notification(packageName = top),
                actions = listOf(
                    ActionStep.BobDraft(instruction = "Summarize and draft a polite reply", packageName = top),
                ),
                rationale = "Frequent notifications from $top",
            ),
        )
    }

    suspend fun summarizePackage(packageName: String): String = summarize(inbox.thread(packageName))

    private fun heuristicDraft(instruction: String): String =
        "On it. ${instruction.trim().replaceFirstChar { it.uppercase() }}"

    private fun heuristicSummary(thread: String): String {
        val lines = thread.lines().filter { it.isNotBlank() }
        return "BOB digest · ${lines.size} messages. Latest: ${lines.lastOrNull().orEmpty().take(140)}"
    }

    private fun localChat(user: String): String {
        val lower = user.lowercase()
        return when {
            "rule" in lower || "when" in lower ->
                "I can forge a WHEN → DO → UNLESS rule. Example: “When WhatsApp from Mom, draft a reply unless battery below 15%.”"
            "summar" in lower ->
                "Point me at a package (WhatsApp, Telegram) and I’ll digest the captured thread."
            "takeover" in lower || "overlay" in lower ->
                "Enable overlay + accessibility + notification listener. Then I fly the HUD over every app."
            else ->
                "BOB online. I automate calls, SMS, deep links, notification replies, and UI macros. Give a directive."
        }
    }

    private fun heuristicParse(utterance: String): RuleDraft {
        val lower = utterance.lowercase()
        val pkg = when {
            "whatsapp" in lower -> "com.whatsapp"
            "telegram" in lower -> "org.telegram.messenger"
            "gmail" in lower -> "com.google.android.gm"
            else -> "com.whatsapp"
        }
        val trigger = when {
            "wifi" in lower -> Trigger.WifiConnected()
            "open" in lower -> Trigger.AppLifecycle(pkg, opened = true)
            else -> Trigger.Notification(packageName = pkg, textContains = null)
        }
        val actions = buildList {
            if ("call" in lower) add(ActionStep.Call(number = digits(utterance)))
            if ("sms" in lower || "text" in lower) add(ActionStep.Sms(number = digits(utterance), message = "BOB ping"))
            if ("reply" in lower || "draft" in lower) {
                add(ActionStep.BobDraft(instruction = utterance, packageName = pkg))
            }
            if (isEmpty()) add(ActionStep.OpenApp(packageName = pkg))
        }
        return RuleDraft(
            name = utterance.take(42),
            trigger = trigger,
            actions = actions,
            rationale = "Parsed on-device by BOB",
        )
    }

    private fun digits(raw: String): String =
        raw.filter { it.isDigit() || it == '+' }.ifBlank { "+10000000000" }

    private suspend fun complete(prompt: String, fallback: String): String = withContext(Dispatchers.IO) {
        val key = settings.apiKey() ?: return@withContext fallback
        val cfg = settings.settings.first()
        val body = json.encodeToString(
            ChatRequest(
                model = cfg.bobModel,
                messages = listOf(
                    ChatMsg("system", "You are BOB, a cyber autopilot AI. Short answers."),
                    ChatMsg("user", prompt),
                ),
            ),
        )
        val req = Request.Builder()
            .url(cfg.bobEndpoint)
            .header("Authorization", "Bearer $key")
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()
        runCatching {
            http.newCall(req).execute().use { response ->
                val payload = response.body?.string().orEmpty()
                json.decodeFromString<ChatResponse>(payload).choices.firstOrNull()?.message?.content ?: fallback
            }
        }.getOrDefault(fallback)
    }
}

@Serializable
private data class ChatRequest(val model: String, val messages: List<ChatMsg>)

@Serializable
private data class ChatMsg(val role: String, val content: String)

@Serializable
private data class ChatResponse(val choices: List<Choice> = emptyList())

@Serializable
private data class Choice(val message: ChatMsg? = null)
