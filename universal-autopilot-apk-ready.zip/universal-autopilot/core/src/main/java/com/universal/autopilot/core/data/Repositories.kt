package com.universal.autopilot.core.data

import com.universal.autopilot.core.data.db.AutopilotDatabase
import com.universal.autopilot.core.data.db.ChatEntity
import com.universal.autopilot.core.data.db.DraftEntity
import com.universal.autopilot.core.data.db.ExecutionEntity
import com.universal.autopilot.core.data.db.RetryEntity
import com.universal.autopilot.core.data.db.RuleEntity
import com.universal.autopilot.core.model.AutomationRule
import com.universal.autopilot.core.model.BobMessage
import com.universal.autopilot.core.model.BobRole
import com.universal.autopilot.core.model.ExecutionRecord
import com.universal.autopilot.core.model.ExecutionStatus
import com.universal.autopilot.core.model.PendingDraft
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RuleRepository @Inject constructor(
    private val db: AutopilotDatabase,
    private val json: Json,
) {
    fun observeRules(): Flow<List<AutomationRule>> =
        db.rules().observe().map { rows -> rows.map { json.decodeFromString(it.payloadJson) } }

    suspend fun enabledRules(): List<AutomationRule> =
        db.rules().enabled().map { json.decodeFromString(it.payloadJson) }

    suspend fun get(id: String): AutomationRule? =
        db.rules().byId(id)?.let { json.decodeFromString(it.payloadJson) }

    suspend fun save(rule: AutomationRule) {
        val stamped = rule.copy(updatedAt = System.currentTimeMillis())
        db.rules().upsert(
            RuleEntity(
                id = stamped.id,
                name = stamped.name,
                enabled = stamped.enabled,
                payloadJson = json.encodeToString(stamped),
                updatedAt = stamped.updatedAt,
            ),
        )
    }

    suspend fun delete(id: String) = db.rules().delete(id)
}

@Singleton
class RuntimeRepository @Inject constructor(
    private val db: AutopilotDatabase,
    private val json: Json,
) {
    fun observeExecutions(): Flow<List<ExecutionRecord>> =
        db.executions().observe().map { rows ->
            rows.map {
                ExecutionRecord(
                    id = it.id,
                    ruleId = it.ruleId,
                    ruleName = it.ruleName,
                    status = ExecutionStatus.valueOf(it.status),
                    message = it.message,
                    attempt = it.attempt,
                    timestamp = it.timestamp,
                )
            }
        }

    suspend fun log(record: ExecutionRecord) {
        db.executions().insert(
            ExecutionEntity(
                id = record.id,
                ruleId = record.ruleId,
                ruleName = record.ruleName,
                status = record.status.name,
                message = record.message,
                attempt = record.attempt,
                timestamp = record.timestamp,
            ),
        )
    }

    fun observeChat(): Flow<List<BobMessage>> =
        db.chat().observe().map { rows ->
            rows.map {
                BobMessage(
                    id = it.id,
                    role = BobRole.valueOf(it.role),
                    content = it.content,
                    timestamp = it.timestamp,
                    pendingDraft = it.pendingDraft,
                )
            }
        }

    suspend fun addChat(message: BobMessage) {
        db.chat().insert(
            ChatEntity(
                id = message.id,
                role = message.role.name,
                content = message.content,
                timestamp = message.timestamp,
                pendingDraft = message.pendingDraft,
            ),
        )
    }

    fun observeDrafts(): Flow<List<PendingDraft>> =
        db.drafts().observe().map { rows -> rows.map { json.decodeFromString(it.payloadJson) } }

    suspend fun saveDraft(draft: PendingDraft) {
        db.drafts().upsert(DraftEntity(draft.id, json.encodeToString(draft)))
    }

    suspend fun getDraft(id: String): PendingDraft? =
        db.drafts().byId(id)?.let { json.decodeFromString(it.payloadJson) }

    suspend fun deleteDraft(id: String) = db.drafts().delete(id)

    suspend fun scheduleRetry(ruleId: String, attempt: Int, runAt: Long) {
        db.retries().upsert(
            RetryEntity(
                id = UUID.randomUUID().toString(),
                ruleId = ruleId,
                attempt = attempt,
                runAt = runAt,
            ),
        )
    }

    suspend fun dueRetries(now: Long) = db.retries().due(now)

    suspend fun clearRetry(id: String) = db.retries().delete(id)
}
