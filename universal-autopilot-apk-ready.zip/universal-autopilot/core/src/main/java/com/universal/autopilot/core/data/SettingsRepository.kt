package com.universal.autopilot.core.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.universal.autopilot.core.common.PrefKeys
import com.universal.autopilot.core.crypto.DatabaseKeyProvider
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.autopilotStore by preferencesDataStore("autopilot_prefs")

data class AutopilotSettings(
    val onboarded: Boolean,
    val takeoverEnabled: Boolean,
    val bobEndpoint: String,
    val bobModel: String,
    val hasApiKey: Boolean,
)

@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val secrets: DatabaseKeyProvider,
) {
    private val onboarded = booleanPreferencesKey(PrefKeys.ONBOARDED)
    private val takeover = booleanPreferencesKey(PrefKeys.TAKEOVER_ENABLED)
    private val endpoint = stringPreferencesKey(PrefKeys.BOB_ENDPOINT)
    private val model = stringPreferencesKey(PrefKeys.BOB_MODEL)

    val settings: Flow<AutopilotSettings> = context.autopilotStore.data.map { prefs ->
        AutopilotSettings(
            onboarded = prefs[onboarded] == true,
            takeoverEnabled = prefs[takeover] != false,
            bobEndpoint = prefs[endpoint] ?: "https://api.openai.com/v1/chat/completions",
            bobModel = prefs[model] ?: "gpt-4o-mini",
            hasApiKey = !secrets.getSecret(PrefKeys.BOB_API_KEY).isNullOrBlank(),
        )
    }

    suspend fun setOnboarded() {
        context.autopilotStore.edit { it[onboarded] = true }
    }

    suspend fun setTakeover(enabled: Boolean) {
        context.autopilotStore.edit { it[takeover] = enabled }
    }

    suspend fun setBobConfig(endpointValue: String, modelValue: String, apiKey: String?) {
        context.autopilotStore.edit {
            it[endpoint] = endpointValue
            it[model] = modelValue
        }
        if (!apiKey.isNullOrBlank()) {
            secrets.putSecret(PrefKeys.BOB_API_KEY, apiKey)
        }
    }

    fun apiKey(): String? = secrets.getSecret(PrefKeys.BOB_API_KEY)
}
