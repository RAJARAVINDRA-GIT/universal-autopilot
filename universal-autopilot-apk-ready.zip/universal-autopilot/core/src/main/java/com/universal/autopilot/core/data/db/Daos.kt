package com.universal.autopilot.core.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface RuleDao {
    @Query("SELECT * FROM rules ORDER BY updatedAt DESC")
    fun observe(): Flow<List<RuleEntity>>

    @Query("SELECT * FROM rules WHERE enabled = 1")
    suspend fun enabled(): List<RuleEntity>

    @Query("SELECT * FROM rules WHERE id = :id")
    suspend fun byId(id: String): RuleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: RuleEntity)

    @Query("DELETE FROM rules WHERE id = :id")
    suspend fun delete(id: String)
}

@Dao
interface ExecutionDao {
    @Query("SELECT * FROM executions ORDER BY timestamp DESC LIMIT 80")
    fun observe(): Flow<List<ExecutionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: ExecutionEntity)
}

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat ORDER BY timestamp ASC")
    fun observe(): Flow<List<ChatEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: ChatEntity)

    @Query("DELETE FROM chat")
    suspend fun clear()
}

@Dao
interface DraftDao {
    @Query("SELECT * FROM drafts ORDER BY id DESC")
    fun observe(): Flow<List<DraftEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: DraftEntity)

    @Query("DELETE FROM drafts WHERE id = :id")
    suspend fun delete(id: String)

    @Query("SELECT * FROM drafts WHERE id = :id")
    suspend fun byId(id: String): DraftEntity?
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC LIMIT 200")
    fun observe(): Flow<List<CapturedNotificationEntity>>

    @Query("SELECT * FROM notifications WHERE packageName = :pkg ORDER BY timestamp DESC LIMIT 40")
    suspend fun forPackage(pkg: String): List<CapturedNotificationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: CapturedNotificationEntity)

    @Query("SELECT * FROM notifications WHERE canReply = 1 AND packageName = :pkg ORDER BY timestamp DESC LIMIT 1")
    suspend fun latestReplyTarget(pkg: String): CapturedNotificationEntity?
}

@Dao
interface RetryDao {
    @Query("SELECT * FROM retry_queue WHERE runAt <= :now")
    suspend fun due(now: Long): List<RetryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: RetryEntity)

    @Query("DELETE FROM retry_queue WHERE id = :id")
    suspend fun delete(id: String)
}
