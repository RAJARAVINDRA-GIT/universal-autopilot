package com.universal.autopilot.core.data

import com.universal.autopilot.core.data.db.AutopilotDatabase
import com.universal.autopilot.core.data.db.CapturedNotificationEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

data class CapturedNotification(
    val key: String,
    val packageName: String,
    val title: String,
    val text: String,
    val timestamp: Long,
    val canReply: Boolean,
)

@Singleton
class NotificationInbox @Inject constructor(
    private val db: AutopilotDatabase,
) {
    fun observe(): Flow<List<CapturedNotificationEntity>> = db.notifications().observe()

    suspend fun capture(
        key: String,
        packageName: String,
        title: String,
        text: String,
        canReply: Boolean,
    ) {
        db.notifications().upsert(
            CapturedNotificationEntity(
                key = key,
                packageName = packageName,
                title = title,
                text = text,
                timestamp = System.currentTimeMillis(),
                canReply = canReply,
            ),
        )
    }

    suspend fun thread(packageName: String): String =
        db.notifications().forPackage(packageName)
            .joinToString("\n") { "${it.title}: ${it.text}" }

    suspend fun latestReplyTarget(packageName: String) = db.notifications().latestReplyTarget(packageName)
}
