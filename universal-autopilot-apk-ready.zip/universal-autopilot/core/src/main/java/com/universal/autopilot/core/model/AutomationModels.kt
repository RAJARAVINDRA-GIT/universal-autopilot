package com.universal.autopilot.core.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
data class AutomationRule(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val enabled: Boolean = true,
    val trigger: Trigger,
    val actions: List<ActionStep>,
    val unless: List<UnlessCondition> = emptyList(),
    val retry: RetryPolicy = RetryPolicy(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)

@Serializable
data class RetryPolicy(
    val retryAfterMinutes: Int = 5,
    val maxAttempts: Int = 3,
)

@Serializable
sealed interface Trigger {
    @Serializable
    @SerialName("time")
    data class Schedule(
        val hour: Int,
        val minute: Int,
        val daysOfWeek: Set<Int> = setOf(1, 2, 3, 4, 5, 6, 7),
    ) : Trigger

    @Serializable
    @SerialName("notification")
    data class Notification(
        val packageName: String,
        val titleContains: String? = null,
        val textContains: String? = null,
        val chatContains: String? = null,
    ) : Trigger

    @Serializable
    @SerialName("wifi")
    data class WifiConnected(val ssid: String? = null) : Trigger

    @Serializable
    @SerialName("geofence")
    data class GeofenceEnter(
        val latitude: Double,
        val longitude: Double,
        val radiusMeters: Float = 120f,
        val enter: Boolean = true,
    ) : Trigger

    @Serializable
    @SerialName("app_lifecycle")
    data class AppLifecycle(
        val packageName: String,
        val opened: Boolean = true,
    ) : Trigger
}

@Serializable
sealed interface ActionStep {
    val id: String

    @Serializable
    @SerialName("call")
    data class Call(
        override val id: String = UUID.randomUUID().toString(),
        val number: String,
    ) : ActionStep

    @Serializable
    @SerialName("sms")
    data class Sms(
        override val id: String = UUID.randomUUID().toString(),
        val number: String,
        val message: String,
    ) : ActionStep

    @Serializable
    @SerialName("deeplink")
    data class DeepLink(
        override val id: String = UUID.randomUUID().toString(),
        val uri: String,
        val packageName: String? = null,
    ) : ActionStep

    @Serializable
    @SerialName("open_app")
    data class OpenApp(
        override val id: String = UUID.randomUUID().toString(),
        val packageName: String,
    ) : ActionStep

    @Serializable
    @SerialName("notif_reply")
    data class NotificationReply(
        override val id: String = UUID.randomUUID().toString(),
        val packageName: String,
        val text: String,
        val keyContains: String? = null,
    ) : ActionStep

    @Serializable
    @SerialName("ui_macro")
    data class UiMacro(
        override val id: String = UUID.randomUUID().toString(),
        val steps: List<UiGesture>,
    ) : ActionStep

    @Serializable
    @SerialName("bob_draft")
    data class BobDraft(
        override val id: String = UUID.randomUUID().toString(),
        val instruction: String,
        val channel: DraftChannel = DraftChannel.NOTIFICATION,
        val packageName: String? = null,
        val number: String? = null,
        val requireApproval: Boolean = true,
    ) : ActionStep
}

@Serializable
enum class DraftChannel { NOTIFICATION, SMS, DEEPLINK }

@Serializable
sealed interface UiGesture {
    @Serializable
    @SerialName("tap")
    data class Tap(val x: Float, val y: Float) : UiGesture

    @Serializable
    @SerialName("tap_text")
    data class TapText(val text: String) : UiGesture

    @Serializable
    @SerialName("type")
    data class Type(val text: String) : UiGesture

    @Serializable
    @SerialName("scroll")
    data class Scroll(val down: Boolean = true) : UiGesture

    @Serializable
    @SerialName("wait")
    data class Wait(val millis: Long = 400) : UiGesture

    @Serializable
    @SerialName("back")
    data object Back : UiGesture

    @Serializable
    @SerialName("home")
    data object Home : UiGesture

    @Serializable
    @SerialName("view_id")
    data class ClickViewId(val viewId: String) : UiGesture
}

@Serializable
sealed interface UnlessCondition {
    @Serializable
    @SerialName("no_wifi")
    data object NoWifi : UnlessCondition

    @Serializable
    @SerialName("battery")
    data class BatteryBelow(val percent: Int) : UnlessCondition

    @Serializable
    @SerialName("locked")
    data object DeviceLocked : UnlessCondition

    @Serializable
    @SerialName("app_missing")
    data class AppNotInstalled(val packageName: String) : UnlessCondition

    @Serializable
    @SerialName("not_charging")
    data object NotCharging : UnlessCondition
}

@Serializable
data class RuleDraft(
    val name: String,
    val trigger: Trigger,
    val actions: List<ActionStep>,
    val unless: List<UnlessCondition> = emptyList(),
    val rationale: String = "",
)

@Serializable
data class BehaviorSignal(
    val packageName: String,
    val title: String,
    val text: String,
    val timestamp: Long,
)
