package com.universal.autopilot.core.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Typography

val Void = Color(0xFF05070F)
val Glass = Color(0x66101828)
val Cyan = Color(0xFF14F1FF)
val Magenta = Color(0xFFFF2BD6)
val Amber = Color(0xFFFFC107)
val GridLine = Color(0x2214F1FF)
val Danger = Color(0xFFFF4D6D)
val Success = Color(0xFF39FF14)

private val CyberColors: ColorScheme = darkColorScheme(
    primary = Cyan,
    onPrimary = Void,
    secondary = Magenta,
    onSecondary = Color.White,
    background = Void,
    onBackground = Color(0xFFE8F6FF),
    surface = Glass,
    onSurface = Color(0xFFE8F6FF),
    error = Danger,
    outline = Cyan.copy(alpha = 0.45f),
)

private val CyberType = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 34.sp,
        letterSpacing = 2.sp,
        color = Cyan,
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp,
        letterSpacing = 1.4.sp,
        color = Cyan,
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp,
        letterSpacing = 1.1.sp,
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 14.sp,
        letterSpacing = 0.4.sp,
        lineHeight = 20.sp,
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontSize = 12.sp,
        letterSpacing = 1.6.sp,
        color = Cyan,
    ),
)

@Composable
fun AutopilotTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = CyberColors,
        typography = CyberType,
        content = content,
    )
}
