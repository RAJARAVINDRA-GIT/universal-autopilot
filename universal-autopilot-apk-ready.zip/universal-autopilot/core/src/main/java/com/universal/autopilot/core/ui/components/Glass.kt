package com.universal.autopilot.core.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.universal.autopilot.core.ui.theme.Cyan
import com.universal.autopilot.core.ui.theme.Glass
import com.universal.autopilot.core.ui.theme.GridLine
import com.universal.autopilot.core.ui.theme.Magenta
import com.universal.autopilot.core.ui.theme.Void

@Composable
fun CyberBackdrop(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Void, androidx.compose.ui.graphics.Color(0xFF0A1224), Void),
                ),
            )
            .drawBehind {
                val step = 42.dp.toPx()
                var x = 0f
                while (x < size.width) {
                    drawLine(GridLine, Offset(x, 0f), Offset(x, size.height), 1f)
                    x += step
                }
                var y = 0f
                while (y < size.height) {
                    drawLine(GridLine, Offset(0f, y), Offset(size.width, y), 1f)
                    y += step
                }
            },
        content = content,
    )
}

@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    accentMagenta: Boolean = false,
    padding: Dp = 16.dp,
    content: @Composable () -> Unit,
) {
    val stroke = if (accentMagenta) Magenta.copy(alpha = 0.7f) else Cyan.copy(alpha = 0.55f)
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(Glass)
            .border(1.dp, stroke, RoundedCornerShape(18.dp))
            .padding(padding),
    ) { content() }
}
