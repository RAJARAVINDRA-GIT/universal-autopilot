package com.universal.autopilot.core.model

import kotlinx.serialization.Serializable

@Serializable
data class BobMessage(
    val id: String,
    val role: BobRole,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val pendingDraft: String? = null,
)

@Serializable
enum class BobRole { USER, BOB, SYSTEM }

@Serializable
data class PendingDraft(
    val id: String,
    val ruleId: String?,
    val actionId: String?,
    val body: String,
    val channel: DraftChannel,
    val packageName: String? = null,
    val number: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
)

@Serializable
data class ExecutionRecord(
    val id: String,
    val ruleId: String,
    val ruleName: String,
    val status: ExecutionStatus,
    val message: String,
    val attempt: Int,
    val timestamp: Long = System.currentTimeMillis(),
)

@Serializable
enum class ExecutionStatus { RUNNING, SUCCESS, FAILED, SKIPPED, WAITING_APPROVAL, RETRY_SCHEDULED }

data class ActionResult(
    val success: Boolean,
    val usedMethod: ExecutionMethod,
    val detail: String,
)

enum class ExecutionMethod { INTENT, NOTIFICATION, ACCESSIBILITY, BLOCKED, NONE }
