package com.universal.autopilot.core.data.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        RuleEntity::class,
        ExecutionEntity::class,
        ChatEntity::class,
        DraftEntity::class,
        CapturedNotificationEntity::class,
        RetryEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class AutopilotDatabase : RoomDatabase() {
    abstract fun rules(): RuleDao
    abstract fun executions(): ExecutionDao
    abstract fun chat(): ChatDao
    abstract fun drafts(): DraftDao
    abstract fun notifications(): NotificationDao
    abstract fun retries(): RetryDao
}
