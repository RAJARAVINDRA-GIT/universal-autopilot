package com.universal.autopilot.core.common

object AutopilotIds {
    const val APPLICATION_ID = "com.universal.autopilot"
    const val BOB_NAME = "BOB"
    const val CHANNEL_CORE = "autopilot.core"
    const val CHANNEL_HUD = "autopilot.hud"
    const val FOREGROUND_ID = 2107
    const val OVERLAY_ID = 2108
}

object PrefKeys {
    const val ONBOARDED = "onboarded"
    const val BOB_ENDPOINT = "bob_endpoint"
    const val BOB_API_KEY = "bob_api_key"
    const val BOB_MODEL = "bob_model"
    const val TAKEOVER_ENABLED = "takeover_enabled"
    const val DATABASE_READY = "database_ready"
}
