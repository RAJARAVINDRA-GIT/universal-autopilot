package com.universal.autopilot.core.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "rules")
data class RuleEntity(
    @PrimaryKey val id: String,
    val name: String,
    val enabled: Boolean,
    val payloadJson: String,
    val updatedAt: Long,
)

@Entity(tableName = "executions")
data class ExecutionEntity(
    @PrimaryKey val id: String,
    val ruleId: String,
    val ruleName: String,
    val status: String,
    val message: String,
    val attempt: Int,
    val timestamp: Long,
)

@Entity(tableName = "chat")
data class ChatEntity(
    @PrimaryKey val id: String,
    val role: String,
    val content: String,
    val timestamp: Long,
    val pendingDraft: String?,
)

@Entity(tableName = "drafts")
data class DraftEntity(
    @PrimaryKey val id: String,
    val payloadJson: String,
)

@Entity(tableName = "notifications")
data class CapturedNotificationEntity(
    @PrimaryKey val key: String,
    val packageName: String,
    val title: String,
    val text: String,
    val timestamp: Long,
    val canReply: Boolean,
)

@Entity(tableName = "retry_queue")
data class RetryEntity(
    @PrimaryKey val id: String,
    val ruleId: String,
    val attempt: Int,
    val runAt: Long,
)
