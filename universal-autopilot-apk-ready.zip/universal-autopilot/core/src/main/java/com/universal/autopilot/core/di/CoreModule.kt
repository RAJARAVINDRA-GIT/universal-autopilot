package com.universal.autopilot.core.di

import android.content.Context
import androidx.room.Room
import com.universal.autopilot.core.crypto.DatabaseKeyProvider
import com.universal.autopilot.core.data.db.AutopilotDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.serialization.json.Json
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object CoreModule {
    @Provides
    @Singleton
    fun json(): Json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        classDiscriminator = "kind"
    }

    @Provides
    @Singleton
    fun database(
        @ApplicationContext context: Context,
        keys: DatabaseKeyProvider,
    ): AutopilotDatabase {
        System.loadLibrary("sqlcipher")
        val factory = SupportOpenHelperFactory(keys.passphrase())
        return Room.databaseBuilder(context, AutopilotDatabase::class.java, "autopilot_secure.db")
            .openHelperFactory(factory)
            .fallbackToDestructiveMigration()
            .build()
    }
}
