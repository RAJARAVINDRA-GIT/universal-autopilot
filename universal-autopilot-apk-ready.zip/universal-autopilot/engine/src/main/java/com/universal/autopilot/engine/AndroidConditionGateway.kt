package com.universal.autopilot.engine

import android.content.Context
import com.universal.autopilot.core.model.UnlessCondition
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import android.app.KeyguardManager
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager

@Singleton
class AndroidConditionGateway @Inject constructor(
    @ApplicationContext private val context: Context,
) : ConditionGateway {
    override fun blockedBy(condition: UnlessCondition): Boolean = when (condition) {
        UnlessCondition.NoWifi -> !hasWifi()
        is UnlessCondition.BatteryBelow -> batteryPercent() < condition.percent
        UnlessCondition.DeviceLocked -> isLocked()
        is UnlessCondition.AppNotInstalled -> !isInstalled(condition.packageName)
        UnlessCondition.NotCharging -> !isCharging()
    }

    private fun hasWifi(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    private fun batteryPercent(): Int {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val battery = context.registerReceiver(null, filter) ?: return 100
        val level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, 100)
        val scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        return if (scale == 0) 100 else (level * 100) / scale
    }

    private fun isLocked(): Boolean {
        val km = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return km.isKeyguardLocked
    }

    private fun isInstalled(packageName: String): Boolean =
        runCatching { context.packageManager.getPackageInfo(packageName, 0); true }.getOrDefault(false)

    private fun isCharging(): Boolean {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val battery = context.registerReceiver(null, filter) ?: return false
        val status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        return status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
    }
}
