package com.universal.autopilot.engine

import com.universal.autopilot.core.model.ActionResult
import com.universal.autopilot.core.model.ActionStep
import com.universal.autopilot.core.model.UiGesture
import com.universal.autopilot.core.model.UnlessCondition

interface DeviceActionGateway {
    suspend fun execute(step: ActionStep): ActionResult
    suspend fun runMacro(steps: List<UiGesture>): ActionResult
    suspend fun announce(title: String, detail: String)
    suspend fun abortTakeover()
}

interface ConditionGateway {
    fun blockedBy(condition: UnlessCondition): Boolean
}

interface BobGateway {
    suspend fun draft(instruction: String, context: String): String
    suspend fun summarize(thread: String): String
    suspend fun parseRule(utterance: String): Result<com.universal.autopilot.core.model.RuleDraft>
    suspend fun chat(history: List<com.universal.autopilot.core.model.BobMessage>, user: String): String
    suspend fun suggest(signals: List<com.universal.autopilot.core.model.BehaviorSignal>): List<com.universal.autopilot.core.model.RuleDraft>
}
