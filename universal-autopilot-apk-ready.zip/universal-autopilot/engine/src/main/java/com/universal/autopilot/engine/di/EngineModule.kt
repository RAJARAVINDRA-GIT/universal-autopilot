package com.universal.autopilot.engine.di

import com.universal.autopilot.engine.AndroidConditionGateway
import com.universal.autopilot.engine.ConditionGateway
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class EngineModule {
    @Binds
    @Singleton
    abstract fun conditions(impl: AndroidConditionGateway): ConditionGateway
}
