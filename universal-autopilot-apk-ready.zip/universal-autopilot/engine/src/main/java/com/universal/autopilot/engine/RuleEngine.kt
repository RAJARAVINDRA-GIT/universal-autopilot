package com.universal.autopilot.engine

import com.universal.autopilot.core.data.RuleRepository
import com.universal.autopilot.core.data.RuntimeRepository
import com.universal.autopilot.core.model.AutomationRule
import com.universal.autopilot.core.model.Trigger
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RuleEngine @Inject constructor(
    private val rules: RuleRepository,
    private val runtime: RuntimeRepository,
    private val runner: ActionRunner,
) {
    suspend fun onNotification(packageName: String, title: String, text: String) {
        matchAndRun { trigger ->
            trigger is Trigger.Notification &&
                trigger.packageName == packageName &&
                trigger.titleContains.orEmpty().let { it.isBlank() || title.contains(it, true) } &&
                trigger.textContains.orEmpty().let { it.isBlank() || text.contains(it, true) } &&
                trigger.chatContains.orEmpty().let { it.isBlank() || title.contains(it, true) || text.contains(it, true) }
        }
    }

    suspend fun onWifi(ssid: String?) {
        matchAndRun { trigger ->
            trigger is Trigger.WifiConnected && (trigger.ssid.isNullOrBlank() || trigger.ssid.equals(ssid, true))
        }
    }

    suspend fun onApp(packageName: String, opened: Boolean) {
        matchAndRun { trigger ->
            trigger is Trigger.AppLifecycle && trigger.packageName == packageName && trigger.opened == opened
        }
    }

    suspend fun onSchedule(hour: Int, minute: Int, dayOfWeekIso: Int) {
        matchAndRun { trigger ->
            trigger is Trigger.Schedule &&
                trigger.hour == hour &&
                trigger.minute == minute &&
                trigger.daysOfWeek.contains(dayOfWeekIso)
        }
    }

    suspend fun onGeofence(enter: Boolean) {
        matchAndRun { trigger ->
            trigger is Trigger.GeofenceEnter && trigger.enter == enter
        }
    }

    suspend fun runById(id: String, attempt: Int = 1) {
        rules.get(id)?.let { runner.run(it, attempt) }
    }

    suspend fun processRetries(now: Long = System.currentTimeMillis()) {
        runtime.dueRetries(now).forEach { item ->
            runtime.clearRetry(item.id)
            runById(item.ruleId, item.attempt)
        }
    }

    private suspend fun matchAndRun(predicate: (Trigger) -> Boolean) {
        rules.enabledRules()
            .filter { predicate(it.trigger) }
            .forEach { rule: AutomationRule -> runner.run(rule) }
    }
}
