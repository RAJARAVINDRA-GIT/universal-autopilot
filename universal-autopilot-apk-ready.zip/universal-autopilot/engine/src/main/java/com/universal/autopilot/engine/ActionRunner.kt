package com.universal.autopilot.engine

import com.universal.autopilot.core.data.RuntimeRepository
import com.universal.autopilot.core.model.ActionResult
import com.universal.autopilot.core.model.ActionStep
import com.universal.autopilot.core.model.AutomationRule
import com.universal.autopilot.core.model.DraftChannel
import com.universal.autopilot.core.model.ExecutionRecord
import com.universal.autopilot.core.model.ExecutionStatus
import com.universal.autopilot.core.model.PendingDraft
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ActionRunner @Inject constructor(
    private val devices: DeviceActionGateway,
    private val conditions: ConditionGateway,
    private val bob: BobGateway,
    private val runtime: RuntimeRepository,
) {
    suspend fun run(rule: AutomationRule, attempt: Int = 1, force: Boolean = false): ExecutionStatus {
        val blocked = rule.unless.firstOrNull { conditions.blockedBy(it) }
        if (blocked != null && !force) {
            runtime.log(
                ExecutionRecord(
                    id = UUID.randomUUID().toString(),
                    ruleId = rule.id,
                    ruleName = rule.name,
                    status = ExecutionStatus.SKIPPED,
                    message = "UNLESS blocked: $blocked",
                    attempt = attempt,
                ),
            )
            return ExecutionStatus.SKIPPED
        }
        devices.announce("BOB takeover", rule.name)
        var last: ActionResult? = null
        for (step in rule.actions) {
            last = when (step) {
                is ActionStep.BobDraft -> handleDraft(rule, step)
                else -> devices.execute(step)
            }
            if (last?.success != true) break
        }
        val success = last?.success == true || rule.actions.isEmpty()
        if (!success && attempt < rule.retry.maxAttempts) {
            val runAt = System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(rule.retry.retryAfterMinutes.toLong())
            runtime.scheduleRetry(rule.id, attempt + 1, runAt)
            runtime.log(
                ExecutionRecord(
                    id = UUID.randomUUID().toString(),
                    ruleId = rule.id,
                    ruleName = rule.name,
                    status = ExecutionStatus.RETRY_SCHEDULED,
                    message = last?.detail ?: "failed",
                    attempt = attempt,
                ),
            )
            return ExecutionStatus.RETRY_SCHEDULED
        }
        val status = if (success) ExecutionStatus.SUCCESS else ExecutionStatus.FAILED
        runtime.log(
            ExecutionRecord(
                id = UUID.randomUUID().toString(),
                ruleId = rule.id,
                ruleName = rule.name,
                status = status,
                message = last?.detail ?: "done via ${last?.usedMethod}",
                attempt = attempt,
            ),
        )
        return status
    }

    private suspend fun handleDraft(rule: AutomationRule, step: ActionStep.BobDraft): ActionResult {
        val body = bob.draft(step.instruction, "Rule ${rule.name}")
        if (step.requireApproval) {
            runtime.saveDraft(
                PendingDraft(
                    id = UUID.randomUUID().toString(),
                    ruleId = rule.id,
                    actionId = step.id,
                    body = body,
                    channel = step.channel,
                    packageName = step.packageName,
                    number = step.number,
                ),
            )
            return ActionResult(
                success = true,
                usedMethod = com.universal.autopilot.core.model.ExecutionMethod.NONE,
                detail = "BOB draft waiting for approval",
            )
        }
        val send = when (step.channel) {
            DraftChannel.SMS -> ActionStep.Sms(number = step.number.orEmpty(), message = body)
            DraftChannel.NOTIFICATION -> ActionStep.NotificationReply(
                packageName = step.packageName.orEmpty(),
                text = body,
            )
            DraftChannel.DEEPLINK -> ActionStep.DeepLink(uri = body)
        }
        return devices.execute(send)
    }
}
