# Autopilot v2 — Universal App Actions & AI Assistant (BOB)

Android automation console. BOB is the onboard AI. The UI is a cyber glass HUD that can draw over other apps while a foreground service keeps rules alive.

## What it does

1. **Rules:** `WHEN` (time, notification, Wi‑Fi, geofence, app open/close) → `DO` (call, SMS, deep link, open app, notification reply, UI macro, BOB draft) → `UNLESS` (no Wi‑Fi, low battery, locked, app missing, not charging).
2. **Action fallback:** intents / deep links → notification `RemoteInput` → Accessibility gestures.
3. **BOB:** natural-language rules (`/rule …`), thread digest (`/sum package.name`), behavior suggestions, drafts that **never send until you approve**.
4. **Takeover:** overlay HUD, accessibility, notification listener, sticky foreground service, boot restart.

Rules live in an **SQLCipher-encrypted Room** database. The cipher key is stored in EncryptedSharedPreferences.

## Modules

| Module | Role |
| --- | --- |
| `:app` | Compose UI, Hilt app, BOB HTTP brain, FGS |
| `:core` | models, encrypted DB, glass theme |
| `:engine` | rule matcher, retries, condition gates |
| `:platform` | overlay, accessibility, notification listener, intent fallbacks |

## Build an APK

This machine may not have the Android SDK yet. On a PC with **Android Studio Ladybug+** (JDK 17):

1. Open `C:\Users\USER\PROGRAMMING\universal-autopilot`.
2. Let Gradle sync (wrapper uses Gradle 8.11.1).
3. Enable **Developer options** on the phone; or use an emulator (API 26+).
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)**  
   or `.\gradlew.bat assembleDebug`

Debug APK: `app\build\outputs\apk\debug\app-debug.apk`  
Application id: `com.universal.autopilot.debug` for debug, `com.universal.autopilot` for release.

## First-run permissions (required for takeover)

In **LINK** inside the app:

- Display over other apps
- Accessibility → **BOB / Autopilot**
- Notification access
- Ignore battery optimizations
- Phone / SMS / location (for those action types)

Optional: paste an OpenAI-compatible endpoint + API key so BOB uses a remote model. Without a key, BOB still runs on-device heuristics.

## BOB commands

- `/rule when WhatsApp from Mom draft a reply unless battery below 15`
- `/sum com.whatsapp`

## Safety

This is a **user-owned automation assistant**, not a stealth tool. Overlay, accessibility, and SMS/call APIs are requested in the open. Drafts default to **approval required**.
